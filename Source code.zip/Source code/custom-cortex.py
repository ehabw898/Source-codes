#!/usr/bin/env python3
import json
import sys
import time
import datetime
import requests
import traceback
import urllib3
import os
import re
import subprocess
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# =========================
# CONFIG
# =========================

# -------- Cortex --------
CORTEX_BASE = "http://34.229.70.169:9001/cortex"
CORTEX_API_KEY = "API keys"
CORTEX_ORG = "soc-lab"

ANALYZERS = [
    "ValidateObservable",
    "IP-API_1",
    "DShield_lookup_1",
]

POLL_SLEEP = 3
POLL_TIMEOUT = 120

# -------- Logging --------
INTEG_LOG = "/var/ossec/logs/integrations.log"

# -------- Block Decision --------
BLOCK_ON_TAXO_LEVELS = {"malicious", "suspicious"}
BLOCK_IF_IPAPI_HOSTING_TRUE = True
BLOCK_IF_IPAPI_PROXY_TRUE = True

# -------- State --------
BLOCK_TTL_SECONDS = 3600
BLOCK_STATE_FILE = "/var/ossec/var/run/custom-cortex-blocked.json"

CASE_TTL_SECONDS = 3600
CASE_STATE_FILE = "/var/ossec/var/run/custom-cortex-cases.json"

# -------- iptables via sudo --------
IPTABLES_SUDO_BIN = "/usr/bin/sudo"
IPTABLES_BIN = "/usr/sbin/iptables"

# -------- Email --------
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "SMTP_USER_mail"
SMTP_PASS = "rsda eemd hzqg avbu"

EMAIL_FROM = "SMTP_USER_mail"
EMAIL_TO = ["SMTP_USER_mail"]

# -------- TheHive --------
THEHIVE_BASE = "https://34.229.70.169/thehive"
THEHIVE_API_KEY = "API keys"
THEHIVE_VERIFY_SSL = False
THEHIVE_CASE_TEMPLATE = "SSH-BruteForce-Investigation"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# =========================
# LOG
# =========================
def log(msg: str):
    ts = datetime.datetime.utcnow().strftime("%a %b %e %H:%M:%S UTC %Y")
    line = f"{ts} [custom-cortex] {msg}\n"
    try:
        with open(INTEG_LOG, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    try:
        sys.stderr.write(line)
    except Exception:
        pass


# =========================
# EMAIL
# =========================
def send_email(subject: str, body: str):
    msg = MIMEMultipart()
    msg["From"] = EMAIL_FROM
    msg["To"] = ", ".join(EMAIL_TO)
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=30) as server:
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(SMTP_USER, SMTP_PASS)
        server.sendmail(EMAIL_FROM, EMAIL_TO, msg.as_string())


def send_block_email(srcip: str, wazuh_id: str, reasons: list, reports_by_analyzer: dict, result: str):
    subject = f"[SOAR] {result} for {srcip}"

    body = []
    body.append("SOAR email notification")
    body.append("")
    body.append(f"Time (UTC): {datetime.datetime.utcnow().isoformat()}Z")
    body.append(f"Source IP: {srcip}")
    body.append(f"Wazuh Alert ID: {wazuh_id}")
    body.append(f"Action Result: {result}")
    body.append("")

    if reasons:
        body.append("Reasons:")
        for r in reasons:
            body.append(f"- {r}")
        body.append("")

    if reports_by_analyzer:
        body.append("Analyzer summary:")
        for analyzer_name, info in reports_by_analyzer.items():
            body.append(f"- {analyzer_name}")
            for taxo in info.get("taxos", []):
                lvl = taxo.get("level")
                ns = taxo.get("namespace")
                pred = taxo.get("predicate")
                val = taxo.get("value")
                body.append(f"    * {ns}:{pred}={val} (level={lvl})")

            full = info.get("full") or {}
            if full:
                body.append(f"    * full={json.dumps(full, ensure_ascii=False)}")
        body.append("")

    send_email(subject, "\n".join(body))


# =========================
# HEADERS
# =========================
def cortex_headers(for_post=False):
    h = {
        "Accept": "application/json",
        "Authorization": f"Bearer {CORTEX_API_KEY}",
        "X-Auth-Token": CORTEX_API_KEY,
        "X-Organisation": CORTEX_ORG,
    }
    if for_post:
        h["Content-Type"] = "application/json"
    return h


def hive_headers():
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {THEHIVE_API_KEY}",
        "X-Auth-Token": THEHIVE_API_KEY
    }


# =========================
# INPUT PARSE
# =========================
def _get_by_path(d, path):
    cur = d
    for k in path:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return None
    return cur


def pick_src_ip(alert: dict):
    candidates = [
        ("data", "srcip"),
        ("data", "srcIp"),
        ("srcip",),
        ("data", "src_ip"),
        ("data", "client_ip"),
        ("data", "source_ip"),
        ("data", "win", "eventdata", "ipAddress"),
        ("data", "aws", "sourceIPAddress"),
        ("data", "system", "srcip"),
        ("data", "network", "srcip"),
    ]
    for path in candidates:
        v = _get_by_path(alert, path)
        if isinstance(v, str) and v.strip():
            return v.strip()

    try:
        s = json.dumps(alert)
        m = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", s)
        if m:
            return m.group(0)
    except Exception:
        pass

    return None


def load_alerts_from_file(path: str):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        raw = f.read().strip()

    if not raw:
        return []

    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return [obj]
        if isinstance(obj, list):
            return [x for x in obj if isinstance(x, dict)]
    except Exception:
        pass

    alerts = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                alerts.append(obj)
        except Exception:
            continue

    return alerts


# =========================
# CORTEX CALLS
# =========================
def cortex_list_org_analyzers():
    url = f"{CORTEX_BASE}/api/organization/analyzer"
    r = requests.get(url, headers=cortex_headers(False), timeout=20)
    r.raise_for_status()
    arr = r.json()
    return arr if isinstance(arr, list) else []


def cortex_get_analyzer_id_by_name(name: str):
    arr = cortex_list_org_analyzers()
    for a in arr:
        if a.get("name") == name:
            return a.get("id") or a.get("_id")
    return None


def cortex_run_analyzer(analyzer_id: str, ip: str, analyzer_name: str):
    payload = {
        "dataType": "ip",
        "data": ip,
        "tlp": 2,
        "pap": 2,
        "message": f"Wazuh auto-analysis ({analyzer_name}) for {ip}",
    }

    url = f"{CORTEX_BASE}/api/analyzer/{analyzer_id}/run"
    r = requests.post(url, headers=cortex_headers(True), data=json.dumps(payload), timeout=45)

    if r.status_code not in (200, 201):
        log(f"Failed start analyzer='{analyzer_name}' id={analyzer_id} IP={ip} HTTP={r.status_code} resp={r.text[:800]}")
        r.raise_for_status()

    return (r.json() or {}).get("id")


def cortex_get_job(job_id: str):
    url = f"{CORTEX_BASE}/api/job/{job_id}"
    r = requests.get(url, headers=cortex_headers(False), timeout=20)
    r.raise_for_status()
    return r.json()


def cortex_wait_job(job_id: str):
    deadline = time.time() + POLL_TIMEOUT
    last = None
    while time.time() < deadline:
        j = cortex_get_job(job_id)
        last = j
        status = (j.get("status") or "").lower()
        if status in ("success", "failure", "error"):
            return j
        time.sleep(POLL_SLEEP)
    return last


def cortex_get_report(job_id: str):
    url = f"{CORTEX_BASE}/api/job/{job_id}/report"
    r = requests.get(url, headers=cortex_headers(False), timeout=45)
    r.raise_for_status()
    return r.json()


def extract_taxonomies(report_payload: dict):
    rep = report_payload.get("report")
    rpt = rep if isinstance(rep, dict) else report_payload
    summary = rpt.get("summary") or {}
    taxos = summary.get("taxonomies") or []
    return taxos if isinstance(taxos, list) else []


def extract_full_selected(report_payload: dict):
    rep = report_payload.get("report")
    rpt = rep if isinstance(rep, dict) else report_payload
    full_obj = rpt.get("full")
    if not isinstance(full_obj, dict):
        return {}
    wanted = ["status", "country", "countryCode", "regionName", "city", "isp", "org", "as", "reverse", "proxy", "hosting", "query", "score"]
    return {k: full_obj.get(k) for k in wanted if k in full_obj}


def summarize_report(report_payload: dict):
    rep = report_payload.get("report")
    rpt = rep if isinstance(rep, dict) else report_payload

    success = rpt.get("success")
    err = rpt.get("errorMessage")

    taxos = extract_taxonomies(report_payload)
    full_selected = extract_full_selected(report_payload)

    lines = []
    lines.append(f"ReportSuccess={success}")
    if err:
        lines.append(f"ReportError={err}")

    if taxos:
        lines.append("Taxonomies:")
        for t in taxos:
            ns = t.get("namespace")
            pred = t.get("predicate")
            val = t.get("value")
            lvl = t.get("level")
            lines.append(f"- {ns}:{pred}={val} (level={lvl})")
    else:
        lines.append("No taxonomies found.")

    if full_selected:
        lines.append("Full(selected): " + json.dumps(full_selected, ensure_ascii=False))

    return "\n".join(lines)


# =========================
# STATE
# =========================
def _load_state(path: str):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_state(path: str, state: dict):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except Exception:
        pass


def _state_recent(path: str, key: str, ttl: int) -> bool:
    st = _load_state(path)
    ts = st.get(key)
    if not ts:
        return False
    try:
        return (time.time() - float(ts)) < ttl
    except Exception:
        return False


def _state_mark(path: str, key: str):
    st = _load_state(path)
    st[key] = time.time()
    _save_state(path, st)


def recently_blocked(ip: str) -> bool:
    return _state_recent(BLOCK_STATE_FILE, ip, BLOCK_TTL_SECONDS)


def mark_blocked(ip: str):
    _state_mark(BLOCK_STATE_FILE, ip)


def recently_case_created(source_ref: str) -> bool:
    return _state_recent(CASE_STATE_FILE, source_ref, CASE_TTL_SECONDS)


def mark_case_created(source_ref: str):
    _state_mark(CASE_STATE_FILE, source_ref)


# =========================
# IPTABLES
# =========================
def run_cmd(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def iptables_rule_exists(ip: str) -> bool:
    r = run_cmd([IPTABLES_SUDO_BIN, IPTABLES_BIN, "-C", "INPUT", "-s", ip, "-j", "DROP"])
    return r.returncode == 0


def block_ip(ip: str):
    if iptables_rule_exists(ip):
        return "already_exists"

    r = run_cmd([IPTABLES_SUDO_BIN, IPTABLES_BIN, "-I", "INPUT", "-s", ip, "-j", "DROP"])
    if r.returncode != 0:
        raise RuntimeError(
            f"iptables insert failed rc={r.returncode} stderr={r.stderr.strip()}"
        )

    if not iptables_rule_exists(ip):
        raise RuntimeError("iptables insert ran but rule verification failed")

    return "inserted"


# =========================
# THEHIVE
# =========================
def build_title_desc(alert: dict, srcip: str):
    rule = alert.get("rule", {}) or {}
    agent = alert.get("agent", {}) or {}
    title = rule.get("description") or "Wazuh Alert"
    level = rule.get("level")
    rid = rule.get("id")
    agent_name = agent.get("name", "N/A")
    wazuh_id = alert.get("id") or "N/A"
    full_log = alert.get("full_log") or ""

    desc = (
        f"Agent={agent_name} Rule={rid} Level={level} SrcIP={srcip}\n"
        f"WazuhID={wazuh_id}\n\n"
        f"{full_log}"
    )
    return title, desc


def hive_search_alert_by_sourceRef(source_ref: str):
    query = {
        "query": {"_and": [{"_field": "sourceRef", "_value": source_ref}]},
        "range": "0-1",
        "sort": ["-date"]
    }
    url = f"{THEHIVE_BASE}/api/alert/_search"
    r = requests.post(
        url,
        headers=hive_headers(),
        data=json.dumps(query),
        timeout=20,
        verify=THEHIVE_VERIFY_SSL
    )
    if r.status_code != 200:
        log(f"TheHive search failed HTTP {r.status_code}: {r.text[:300]}")
        return None
    arr = r.json()
    if isinstance(arr, list) and len(arr) > 0:
        return arr[0].get("_id") or arr[0].get("id")
    return None


def hive_create_alert_if_missing(source_ref: str, alert: dict, srcip: str):
    existing = hive_search_alert_by_sourceRef(source_ref)
    if existing:
        return existing, False

    title, desc = build_title_desc(alert, srcip)
    rule = alert.get("rule", {}) or {}

    lvl = int(rule.get("level") or 1)
    if lvl >= 12:
        severity = 3
    elif lvl >= 8:
        severity = 2
    else:
        severity = 1

    payload = {
        "type": "external",
        "source": "wazuh",
        "sourceRef": source_ref,
        "title": title,
        "description": desc,
        "severity": severity,
        "tags": ["wazuh", "xdr", "soar", "auto-case"],
        "tlp": 2,
        "pap": 2
    }

    url = f"{THEHIVE_BASE}/api/alert"
    r = requests.post(
        url,
        headers=hive_headers(),
        data=json.dumps(payload),
        timeout=20,
        verify=THEHIVE_VERIFY_SSL
    )

    if r.status_code not in (200, 201):
        log(f"TheHive create alert failed HTTP {r.status_code}: {r.text[:300]}")
        return None, False

    created_id = hive_search_alert_by_sourceRef(source_ref)
    return created_id, True


def hive_add_artifact_to_alert(alert_id: str, data: str, tags=None, dataType="other"):
    if tags is None:
        tags = ["soar", "report"]

    payload = {
        "dataType": dataType,
        "data": data,
        "tlp": 2,
        "pap": 2,
        "tags": tags
    }

    url = f"{THEHIVE_BASE}/api/alert/{alert_id}/artifact"
    r = requests.post(
        url,
        headers=hive_headers(),
        data=json.dumps(payload),
        timeout=25,
        verify=THEHIVE_VERIFY_SSL
    )
    if r.status_code not in (200, 201):
        log(f"TheHive artifact failed HTTP {r.status_code}: {r.text[:300]}")
        return False
    return True


def hive_attach_soar_summary(alert_id: str, srcip: str, reasons: list, reports_by_analyzer: dict, action_result: str):
    lines = []
    lines.append("SOAR automation summary")
    lines.append(f"Source IP: {srcip}")
    lines.append(f"Action result: {action_result}")
    lines.append("")
    lines.append("Reasons:")
    if reasons:
        for r in reasons:
            lines.append(f"- {r}")
    else:
        lines.append("- none")

    lines.append("")
    lines.append("Analyzer summary:")
    for analyzer, info in reports_by_analyzer.items():
        lines.append(f"- {analyzer}")
        taxos = info.get("taxos", []) or []
        full = info.get("full", {}) or {}

        if taxos:
            for t in taxos:
                ns = t.get("namespace")
                pred = t.get("predicate")
                val = t.get("value")
                lvl = t.get("level")
                lines.append(f"    * {ns}:{pred}={val} (level={lvl})")
        else:
            lines.append("    * no taxonomies")

        if full:
            lines.append(f"    * full={json.dumps(full, ensure_ascii=False)}")

    text = "\n".join(lines)
    return hive_add_artifact_to_alert(alert_id, text, tags=["soar", "report"], dataType="other")


def hive_create_case_from_alert_with_template(alert_id: str, title: str, desc: str):
    url = f"{THEHIVE_BASE}/api/v1/alert/{alert_id}/case"

    payload = {
        "title": title,
        "description": desc,
        "caseTemplate": THEHIVE_CASE_TEMPLATE
    }

    r = requests.post(
        url,
        headers=hive_headers(),
        data=json.dumps(payload),
        timeout=30,
        verify=THEHIVE_VERIFY_SSL
    )

    if r.status_code not in (200, 201):
        raise RuntimeError(f"failed to create case from alert {alert_id}: HTTP {r.status_code} resp={r.text[:300]}")

    try:
        obj = r.json()
    except Exception:
        obj = {}

    case_id = obj.get("_id") or obj.get("id") or "created"
    log(f"THEHIVE_CASE_CREATED endpoint={url} case_id={case_id} template={THEHIVE_CASE_TEMPLATE}")
    return case_id


def ensure_thehive_alert_and_case(alert: dict, srcip: str, reasons: list, reports_by_analyzer: dict, action_result: str):
    wazuh_id = alert.get("id") or alert.get("timestamp") or str(time.time())
    source_ref = str(wazuh_id)

    if recently_case_created(source_ref):
        log(f"THEHIVE_CASE_SKIP_ALREADY_CREATED source_ref={source_ref}")
        return

    alert_id, created = hive_create_alert_if_missing(source_ref, alert, srcip)
    if not alert_id:
        raise RuntimeError(f"unable to ensure TheHive alert for sourceRef={source_ref}")

    if created:
        log(f"THEHIVE_ALERT_CREATED alert_id={alert_id} source_ref={source_ref}")
    else:
        log(f"THEHIVE_ALERT_FOUND alert_id={alert_id} source_ref={source_ref}")

    hive_attach_soar_summary(alert_id, srcip, reasons, reports_by_analyzer, action_result)

    title = f"SOAR Case - {alert.get('rule', {}).get('description', 'Wazuh Alert')}"
    desc = (
        f"Auto-created by custom-cortex after SOAR decision.\n\n"
        f"Source IP: {srcip}\n"
        f"Wazuh alert id: {wazuh_id}\n"
        f"Action result: {action_result}\n\n"
        f"Reasons:\n" + "\n".join([f"- {r}" for r in reasons])
    )

    hive_create_case_from_alert_with_template(alert_id, title, desc)
    mark_case_created(source_ref)


# =========================
# DECISION LOGIC
# =========================
def decide_block(reports_by_analyzer: dict):
    reasons = []

    for an, info in reports_by_analyzer.items():
        for t in info.get("taxos", []):
            lvl = (t.get("level") or "").lower()
            if lvl in BLOCK_ON_TAXO_LEVELS:
                ns = t.get("namespace")
                pred = t.get("predicate")
                val = t.get("value")
                reasons.append(f"{an} taxo {ns}:{pred}={val} level={lvl}")

    ipapi_full = (reports_by_analyzer.get("IP-API_1") or {}).get("full") or {}
    if BLOCK_IF_IPAPI_HOSTING_TRUE and ipapi_full.get("hosting") is True:
        reasons.append("IP-API hosting=true")
    if BLOCK_IF_IPAPI_PROXY_TRUE and ipapi_full.get("proxy") is True:
        reasons.append("IP-API proxy=true")

    return (len(reasons) > 0), reasons


# =========================
# PROCESS ALERT
# =========================
def process_one_alert(alert: dict):
    wazuh_id = alert.get("id") or alert.get("timestamp") or "N/A"
    srcip = pick_src_ip(alert)

    if not srcip:
        log(f"No srcip found (wazuh_id={wazuh_id}). Exit.")
        return

    reports_by_analyzer = {}

    for analyzer_name in ANALYZERS:
        analyzer_id = cortex_get_analyzer_id_by_name(analyzer_name)
        if not analyzer_id:
            log(f"Analyzer not found: {analyzer_name} (org={CORTEX_ORG})")
            continue

        log(f"Starting analyzer='{analyzer_name}' id={analyzer_id} for IP={srcip} wazuh_id={wazuh_id}")
        job_id = cortex_run_analyzer(analyzer_id, srcip, analyzer_name)
        if not job_id:
            log(f"[{analyzer_name}] Failed start analyzer for IP={srcip} resp=<no job id>")
            continue

        job = cortex_wait_job(job_id) or {}
        status = job.get("status")
        job_err = job.get("errorMessage")

        summary = ""
        taxos = []
        full_selected = {}
        try:
            report = cortex_get_report(job_id)
            summary = summarize_report(report)
            taxos = extract_taxonomies(report)
            full_selected = extract_full_selected(report)
        except Exception as e:
            summary = f"Failed to fetch/parse report: {e}"

        log(f"[{analyzer_name}] JobId={job_id} Status={status} IP={srcip} wazuh_id={wazuh_id} jobErr={job_err}")
        log(f"[{analyzer_name}] Report:\n{summary}")

        reports_by_analyzer[analyzer_name] = {"taxos": taxos, "full": full_selected}

    should_block, reasons = decide_block(reports_by_analyzer)

    if should_block:
        log(f"DECISION=BLOCK IP={srcip} reasons=" + "; ".join(reasons))

        if recently_blocked(srcip):
            log(f"ACTION=SKIP_ALREADY_BLOCKED ip={srcip} ttl={BLOCK_TTL_SECONDS}s")

            try:
                ensure_thehive_alert_and_case(
                    alert=alert,
                    srcip=srcip,
                    reasons=reasons,
                    reports_by_analyzer=reports_by_analyzer,
                    action_result="SKIP_ALREADY_BLOCKED",
                )
            except Exception as hive_err:
                log(f"THEHIVE_CASE_FAILED ip={srcip} err={hive_err}")

            return

        try:
            result = block_ip(srcip)
            mark_blocked(srcip)
            log(f"ACTION=BLOCK_APPLIED ip={srcip} result={result}")

            try:
                send_block_email(
                    srcip=srcip,
                    wazuh_id=wazuh_id,
                    reasons=reasons,
                    reports_by_analyzer=reports_by_analyzer,
                    result="BLOCK_APPLIED",
                )
                log(f"ACTION=EMAIL_SENT ip={srcip}")
            except Exception as email_err:
                log(f"ACTION=EMAIL_FAILED ip={srcip} err={email_err}")

            try:
                ensure_thehive_alert_and_case(
                    alert=alert,
                    srcip=srcip,
                    reasons=reasons,
                    reports_by_analyzer=reports_by_analyzer,
                    action_result="BLOCK_APPLIED",
                )
            except Exception as hive_err:
                log(f"THEHIVE_CASE_FAILED ip={srcip} err={hive_err}")

        except Exception as e:
            log(f"ACTION=BLOCK_FAILED ip={srcip} err={e}")

            try:
                send_block_email(
                    srcip=srcip,
                    wazuh_id=wazuh_id,
                    reasons=reasons,
                    reports_by_analyzer=reports_by_analyzer,
                    result=f"BLOCK_FAILED ({e})",
                )
                log(f"ACTION=EMAIL_SENT_ON_FAILURE ip={srcip}")
            except Exception as email_err:
                log(f"ACTION=EMAIL_FAILED_ON_FAILURE ip={srcip} err={email_err}")

            try:
                ensure_thehive_alert_and_case(
                    alert=alert,
                    srcip=srcip,
                    reasons=reasons,
                    reports_by_analyzer=reports_by_analyzer,
                    action_result=f"BLOCK_FAILED ({e})",
                )
            except Exception as hive_err:
                log(f"THEHIVE_CASE_FAILED ip={srcip} err={hive_err}")

            mark_blocked(srcip)

    else:
        log(f"DECISION=ALLOW IP={srcip} reasons=<none>")


# =========================
# MAIN
# =========================
def main():
    if len(sys.argv) < 2:
        log("Usage: custom-cortex <alert_json_path>")
        sys.exit(2)

    alert_path = sys.argv[1]
    alerts = load_alerts_from_file(alert_path)

    if not alerts:
        log("No alerts loaded from input. Exit.")
        sys.exit(0)

    if len(alerts) > 1 and os.path.basename(alert_path) == "alerts.json":
        process_one_alert(alerts[-1])
    else:
        for a in alerts:
            process_one_alert(a)

    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log("Unhandled exception: " + str(e))
        log(traceback.format_exc())
        sys.exit(1)
