#!/usr/bin/env python3
import json
import sys
import time
import datetime
import requests
import traceback
import urllib3

# =========================
# CONFIG
# =========================
THEHIVE_BASE = "https://34.229.70.169/thehive"
CORTEX_BASE  = "http://34.229.70.169:9001/cortex"

THEHIVE_API_KEY = "THEHIVE_API_KEY"
CORTEX_API_KEY  = "CORTEX_API_KEY"
CORTEX_ORG      = "soc-lab"

ANALYZER_NAME = "IP-API_1"

THEHIVE_VERIFY_SSL = False

POLL_SLEEP = 3
POLL_TIMEOUT = 90  # seconds

INTEG_LOG = "/var/ossec/logs/integrations.log"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# =========================
# UTIL / LOG
# =========================
def log(msg: str):
    ts = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{ts} custom-thehive: {msg}\n"
    try:
        with open(INTEG_LOG, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    try:
        sys.stderr.write(line)
    except Exception:
        pass


def hive_headers():
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {THEHIVE_API_KEY}",
        "X-Auth-Token": THEHIVE_API_KEY
    }


def cortex_headers(for_post=False):
    h = {
        "Accept": "application/json",
        "Authorization": f"Bearer {CORTEX_API_KEY}",
        "X-Auth-Token": CORTEX_API_KEY,
        "X-Organisation": CORTEX_ORG,   
    }
    if for_post:
        h["Content-Type"] = "application/json"
    return h


def pick_src_ip(alert: dict):
    for path in [
        ("data", "srcip"),
        ("srcip",),
        ("data", "src_ip"),
        ("data", "client_ip"),
        ("data", "source_ip"),
    ]:
        cur = alert
        ok = True
        for k in path:
            if isinstance(cur, dict) and k in cur:
                cur = cur[k]
            else:
                ok = False
                break
        if ok and isinstance(cur, str) and cur.strip():
            return cur.strip()
    return None


def build_title_desc(alert: dict):
    rule = alert.get("rule", {}) or {}
    agent = alert.get("agent", {}) or {}
    title = rule.get("description") or "Wazuh Alert"
    level = rule.get("level")
    rid = rule.get("id")
    agent_name = agent.get("name", "N/A")
    srcip = pick_src_ip(alert) or "N/A"
    wazuh_id = alert.get("id") or "N/A"
    full_log = alert.get("full_log") or ""

    desc = (
        f"Agent={agent_name} Rule={rid} Level={level} SrcIP={srcip}\n"
        f"WazuhID={wazuh_id}\n\n"
        f"{full_log}"
    )
    return title, desc


# =========================
# THEHIVE API
# =========================
def hive_search_alert_by_sourceRef(source_ref: str):
    query = {
        "query": {"_and": [{"_field": "sourceRef", "_value": source_ref}]},
        "range": "0-1",
        "sort": ["-date"]
    }
    url = f"{THEHIVE_BASE}/api/alert/_search"
    r = requests.post(url, headers=hive_headers(), data=json.dumps(query),
                      timeout=20, verify=THEHIVE_VERIFY_SSL)
    if r.status_code != 200:
        log(f"TheHive search failed HTTP {r.status_code}: {r.text[:300]}")
        return None
    arr = r.json()
    if isinstance(arr, list) and len(arr) > 0:
        return arr[0].get("_id") or arr[0].get("id")
    return None


def hive_create_alert_if_missing(source_ref: str, alert: dict):
    existing = hive_search_alert_by_sourceRef(source_ref)
    if existing:
        return existing, False

    title, desc = build_title_desc(alert)
    rule = alert.get("rule", {}) or {}

    lvl = int(rule.get("level") or 1)
    if lvl >= 12:
        severity = 3
    elif lvl >= 8:
        severity = 2
    else:
        severity = 1

    payload = {
        "type": "external",
        "source": "wazuh",
        "sourceRef": source_ref,
        "title": title,
        "description": desc,
        "severity": severity,
        "tags": ["wazuh", "xdr"],
        "tlp": 2,
        "pap": 2
    }

    url = f"{THEHIVE_BASE}/api/alert"
    r = requests.post(url, headers=hive_headers(), data=json.dumps(payload),
                      timeout=20, verify=THEHIVE_VERIFY_SSL)

    if r.status_code not in (200, 201):
        log(f"TheHive create alert failed HTTP {r.status_code}: {r.text[:300]}")
        return None, False

    created_id = hive_search_alert_by_sourceRef(source_ref)
    return created_id, True


def hive_add_artifact_to_alert(alert_id: str, data: str, tags=None, dataType="other"):
    if tags is None:
        tags = ["cortex", "report"]

    payload = {
        "dataType": dataType,
        "data": data,
        "tlp": 2,
        "pap": 2,
        "tags": tags
    }

    url = f"{THEHIVE_BASE}/api/alert/{alert_id}/artifact"
    r = requests.post(url, headers=hive_headers(), data=json.dumps(payload),
                      timeout=25, verify=THEHIVE_VERIFY_SSL)
    if r.status_code not in (200, 201):
        log(f"TheHive artifact failed HTTP {r.status_code}: {r.text[:300]}")
        return False
    return True


# =========================
# CORTEX API (ORG-AWARE)
# =========================
def cortex_list_org_analyzers():
    url = f"{CORTEX_BASE}/api/organization/analyzer"
    r = requests.get(url, headers=cortex_headers(False), timeout=20)
    r.raise_for_status()
    arr = r.json()
    return arr if isinstance(arr, list) else []


def cortex_get_analyzer_id_by_name(name: str):
    arr = cortex_list_org_analyzers()
    for a in arr:
        if a.get("name") == name:
            return a.get("id")
    return None


def cortex_run_analyzer(analyzer_id: str, ip: str):
    payload = {
        "dataType": "ip",
        "data": ip,
        "tlp": 2,
        "pap": 2,
        "message": f"Wazuh auto-analysis for {ip}"
    }

    url = f"{CORTEX_BASE}/api/analyzer/{analyzer_id}/run"
    r = requests.post(url, headers=cortex_headers(True), data=json.dumps(payload), timeout=30)

    
    if r.status_code == 404:
        url2 = f"{CORTEX_BASE}/api/organization/analyzer/{analyzer_id}/run"
        r2 = requests.post(url2, headers=cortex_headers(True), data=json.dumps(payload), timeout=30)
        if r2.status_code not in (200, 201):
            log(f"Cortex run failed (fallback) HTTP {r2.status_code}: {r2.text[:300]}")
            r2.raise_for_status()
        return (r2.json() or {}).get("id")

    if r.status_code not in (200, 201):
        log(f"Cortex run failed HTTP {r.status_code}: {r.text[:300]}")
        r.raise_for_status()

    return (r.json() or {}).get("id")


def cortex_wait_job(job_id: str):
    deadline = time.time() + POLL_TIMEOUT
    last = None
    while time.time() < deadline:
        url = f"{CORTEX_BASE}/api/job/{job_id}"
        r = requests.get(url, headers=cortex_headers(False), timeout=20)
        r.raise_for_status()
        j = r.json()
        last = j
        status = (j.get("status") or "").lower()
        if status in ("success", "failure", "error"):
            return j
        time.sleep(POLL_SLEEP)
    return last


def cortex_get_report(job_id: str):
    url = f"{CORTEX_BASE}/api/job/{job_id}/report"
    r = requests.get(url, headers=cortex_headers(False), timeout=30)
    r.raise_for_status()
    return r.json()


def summarize_cortex(report_payload: dict):
    """
    Cortex 4 returns:
      {
        ...,
        "report": {
          "summary": {"taxonomies":[...]},
          "full": {...},
          "success": true/false,
          ...
        }
      }
    """
    rpt = report_payload.get("report")
    if not isinstance(rpt, dict):
        rpt = report_payload

    success = rpt.get("success")
    err = rpt.get("errorMessage")

    summary = rpt.get("summary")
    taxos = []
    if isinstance(summary, dict):
        taxos = summary.get("taxonomies") or []

    lines = []
    verdict = "Success" if success is True else ("Failure" if success is False else None)

    if err:
        lines.append(f"ReportError: {err}")

    if taxos:
        lines.append("Taxonomies:")
        for t in taxos:
            ns = t.get("namespace")
            pred = t.get("predicate")
            val = t.get("value")
            lvl = t.get("level")
            lines.append(f"- {ns}:{pred}={val} (level={lvl})")
    else:
        lines.append("No taxonomies found in Cortex report.")

    full_obj = rpt.get("full")
    if isinstance(full_obj, dict):
        wanted = ["status", "country", "countryCode", "regionName", "city", "isp", "org", "as", "reverse", "proxy", "hosting", "query"]
        short = {k: full_obj.get(k) for k in wanted if k in full_obj}
        if short:
            lines.append("Full(selected): " + json.dumps(short, ensure_ascii=False))

    return verdict, "\n".join(lines)


# =========================
# MAIN
# =========================
def main():
    if len(sys.argv) < 2:
        log("Usage: custom-thehive <alert_json_path>")
        sys.exit(2)

    alert_path = sys.argv[1]
    with open(alert_path, "r", encoding="utf-8") as f:
        alert = json.load(f)

    wazuh_id = alert.get("id") or alert.get("timestamp") or str(time.time())
    source_ref = str(wazuh_id)

    srcip = pick_src_ip(alert)
    if not srcip:
        log(f"No srcip found in alert {source_ref}. Exit.")
        sys.exit(0)

    # 1) Ensure alert exists in TheHive
    alert_id, created = hive_create_alert_if_missing(source_ref, alert)
    if not alert_id:
        log(f"Failed to ensure TheHive alert for sourceRef={source_ref}")
        sys.exit(1)

    if created:
        log(f"Created TheHive alert {alert_id} for sourceRef={source_ref}")
    else:
        log(f"Found existing TheHive alert {alert_id} for sourceRef={source_ref}")

    # 2) Cortex analysis (ORG-aware)
    analyzer_id = cortex_get_analyzer_id_by_name(ANALYZER_NAME)
    if not analyzer_id:
        log(f"Analyzer not found in Cortex org={CORTEX_ORG}: {ANALYZER_NAME}")
        hive_add_artifact_to_alert(alert_id, f"Cortex analyzer not found: {ANALYZER_NAME}",
                                  tags=["cortex", "error"], dataType="other")
        sys.exit(1)

    job_id = cortex_run_analyzer(analyzer_id, srcip)
    job_state = cortex_wait_job(job_id) or {}
    status = job_state.get("status", "unknown")

    try:
        report = cortex_get_report(job_id)
    except Exception as e:
        report = {"report": {"success": False, "errorMessage": f"Failed to fetch report: {e}"}}

    verdict, details = summarize_cortex(report)

    text = (
        f"🧪 Cortex Auto Analysis (UPDATED)\n"
        f"- Analyzer: {ANALYZER_NAME}\n"
        f"- Observable: {srcip}\n"
        f"- JobId: {job_id}\n"
        f"- Status: {status}\n"
        f"- Verdict: {verdict}\n\n"
        f"{details}\n"
    )

    ok = hive_add_artifact_to_alert(alert_id, text, tags=["cortex", "report"], dataType="other")
    if ok:
        log(f"OK: Added Cortex report artifact to TheHive alert {alert_id}")
        print(f"OK: Added Cortex report artifact to TheHive alert {alert_id}")
    else:
        log(f"Failed to add Cortex report artifact to alert {alert_id}")
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        log("Unhandled exception: " + str(e))
        log(traceback.format_exc())
        sys.exit(1)
